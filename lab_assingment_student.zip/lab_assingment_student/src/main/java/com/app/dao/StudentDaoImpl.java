package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Course;
import com.app.pojos.Student;

@Repository
public class StudentDaoImpl implements StudentDao {
	@Autowired
	private EntityManager mgr;

	@Override
	public String addStudent(Student s) {

		mgr.persist(s);

		return "student added successfully";
	}

	@Override
	public List<Student> getAllStudentDeatils() {
		String jpql = "select s from Student s";
		List<Student> list = mgr.createQuery(jpql, Student.class).getResultList();
		for (Student student : list) {
			System.out.println(student.getRollno());
		}
		return list;
	}

	@Override
	public List<Student> displayAllStudentsByCourse(Course c) {
		String jpql = "select s from Student s where s.courseName =:course";
		List<Student> list = mgr.createQuery(jpql, Student.class).setParameter("course", c).getResultList();
		return list;
	}

	@Override
	public List<Course> getAllCourses() {
		String jpql = "SELECT DISTINCT s.courseName FROM Student s";
		List<Course> list = mgr.createQuery(jpql, Course.class).getResultList();
		return list;
	}

}
