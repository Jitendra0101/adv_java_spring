package com.app.dao;

import java.util.List;

import com.app.pojos.Employee;

public interface EmployeeDao {

	String addEmployee(Employee s);

	List<Employee> getAllEmployeeDeatils();

	List<Employee> getAllEmployeeDeatilsByCompany(String company);

}
