package com.app.dao;

import java.util.List;

import com.app.pojos.Course;
import com.app.pojos.Student;

public interface StudentDao {

	String addStudent(Student s);

	List<Student> getAllStudentDeatils();
	
	List<Student> displayAllStudentsByCourse(Course c);
	
	List<Course> getAllCourses();

}
