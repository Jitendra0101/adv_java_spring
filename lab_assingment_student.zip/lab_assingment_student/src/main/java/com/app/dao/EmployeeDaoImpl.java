package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	private EntityManager mgr;
	@Override
	public String addEmployee(Employee s) {
		
		
		mgr.persist(s);
		
		return "employee added successfully";
	}
	@Override
	public List<Employee> getAllEmployeeDeatils() {
		String jpql="select s from Employee s";
		List<Employee> list=mgr.createQuery(jpql,Employee.class).getResultList();
		for (Employee employee : list) {
			System.out.println(employee.getEmpno());
		}
		return list;
	}
	public List<Employee> getAllEmployeeDeatilsByCompany(String cmp) {
		String jpql="select s from Employee s where s.cmp=:cName ";
		List<Employee> list=mgr.createQuery(jpql,Employee.class).setParameter("cName",cmp).getResultList();
		for (Employee employee : list) {
			System.out.println(employee.getEmpno());
		}
		return list;
	}

}
