package com.app.service;

import java.util.List;

import com.app.pojos.Employee;

public interface EmployeeService {


public String addEmployee(Employee s);

public List<Employee> getAllEmployeeDeatils();


public List<Employee> getAllEmployeeDeatilsByCompany(String company);

}
