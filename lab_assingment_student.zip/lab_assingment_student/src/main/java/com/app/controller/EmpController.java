package com.app.controller;

import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Company;
import com.app.pojos.Employee;
import com.app.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmpController {
	@Autowired
	private EmployeeService sSer;
	public EmpController() {
		System.out.println("in employee controller");
	}

	@GetMapping("/add_employee_form")
	public String  getEmployeeForm() {
		return "/employees/add_employee_form";
		
	}
	@PostMapping("/add")
	public String addEmployee(@RequestParam String fn, @RequestParam String ln,@RequestParam String city,@RequestParam String company, Model map)
	{
		Company c=Company.valueOf(company);//enum (c)
		Employee s=new Employee(fn,ln,city,c);
		String msg= sSer.addEmployee(s);
		map.addAttribute("msg",msg);
		return "/employees/add";
	}
	
	@GetMapping("/display")
	public String getAllEmployeetDeatils(Model map) {
		 List<Employee> employeeList=sSer.getAllEmployeeDeatils();
		 map.addAttribute("employeeList", employeeList);
		return "/employees/display";
	}
	
	@GetMapping("/emp_details")
	public String  getCompany() {
		return "/employees/emp_details";
		
	}
	@PostMapping("/disp_emp_details")
	public String getAllEmployeeDeatilsByCompany(@RequestParam String company, Model map)
	{
		//Company c=Company.valueOf(company);//enum (c)
	    List<Employee> employeeList=sSer.getAllEmployeeDeatilsByCompany(company);
	    map.addAttribute("employeeList", employeeList);
		return "/employees/disp_emp_details";
	}
	
}
