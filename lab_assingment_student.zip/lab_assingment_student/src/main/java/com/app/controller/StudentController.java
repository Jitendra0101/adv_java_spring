package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Course;
import com.app.pojos.Student;
import com.app.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {
	@Autowired
	private StudentService sSer;

	public StudentController() {
		System.out.println("in student controller");
	}

	@GetMapping("/add_student_form")
	public String getStudentForm() {
		return "/students/add_student_form";

	}

	@PostMapping("/add")
	public String addStudent(@RequestParam String fn, @RequestParam String ln, @RequestParam String city,
			@RequestParam String course, Model map) {
		Course c = Course.valueOf(course);
		Student s = new Student(fn, ln, city, c);
		String msg = sSer.addStudent(s);
		map.addAttribute("msg", msg);
		return "/students/add";
	}

	@GetMapping("/display")
	public String getAllStudentDeatils(Model map) {
		List<Student> studentList = sSer.getAllStudentDeatils();
		map.addAttribute("studentList", studentList);
		return "/students/display";
	}

	@GetMapping("/select_course")
	public String SelectCourse(Model map) {
		System.out.println("in SelectCourse...");
		List<Course> courseList = sSer.getAllCourses();
		map.addAttribute("course_list", courseList);
		return "/students/get_course_students";
	}

	@PostMapping("/display_student_by_course")
	public String DisplayStudentsByCourse(@RequestParam String course, Model map) {
		System.out.println("in displayStudentsByCourse...");
		Course c = Course.valueOf(course);
//		List<Student> studentList = sSer.getAllStudentDeatils();
//		map.addAttribute("studentList", studentList);
//		for(Student i : studentList) {
//			System.out.println(i);
//		}
		List<Student> studentCourseList = sSer.displayAllStudentByCourse(c);
		map.addAttribute("displayCourses", studentCourseList);
		return "/students/display_courses";

	}

}
