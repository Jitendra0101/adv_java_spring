package com.app.pojos;

public enum Course {
	DAC,DBDA,DITIS
}
