package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Student {
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="roll_no")
	private int rollno;
	@Column(name="first_name")
	private String studentFirstName;
	@Column(name="last_name")
	private String studentLastName;
	@Column(name="city")
	private String city;
	

	@Enumerated(EnumType.STRING)
	@Column(name="course_name")
	private Course courseName;
	public Student() {
		super();
	}
	
	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Course getCourseName() {
		return courseName;
	}

	public void setCourseName(Course courseName) {
		this.courseName = courseName;
	}

	public Student(String studentFirstName, String studentLastName, String city, Course courseName) {
		super();
		this.studentFirstName = studentFirstName;
		this.studentLastName = studentLastName;
		this.city = city;
		this.courseName = courseName;
	}
}
