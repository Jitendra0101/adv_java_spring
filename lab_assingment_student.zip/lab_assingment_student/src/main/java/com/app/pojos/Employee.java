package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="emp_no")
	private int Empno;
	@Column(name="first_name")
	private String employeeFirstName;
	@Column(name="last_name")
	private String employeeLastName;
	@Column(name="city")
	private String city;
	

	@Enumerated(EnumType.STRING)
	@Column(name="company_name")
	private Company companyName;
	//private Object employeeFirstName;
	public Employee() {
		super();
	}
	
	public int getEmpno() {
		return Empno;
	}

	public void setEmpno(int Empno) {
		this.Empno = Empno;
	}

	public String getEmployeeFirstName() {
		return employeeFirstName;
	}

	public void setEmployeeFirstName(String employeeFirstName) {
		this.employeeFirstName = employeeFirstName;
	}

	public String getemployeeLastName() {
		return employeeLastName;
	}

	public void setemployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Company getcompanyName() {
		return companyName;
	}

	public Employee(String employeeFirstName, String employeeLastName, String city, Company companyName) {
		super();
		this.employeeFirstName = employeeFirstName;
		this.employeeLastName = employeeLastName;
		this.city = city;
		this.companyName = companyName;
	}

	public void setcompanyName(Company companyName) {
		this.companyName = companyName;
	}

	
}
