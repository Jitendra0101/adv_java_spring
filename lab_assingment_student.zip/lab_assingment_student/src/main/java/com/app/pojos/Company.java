package com.app.pojos;

public enum Company {
	TCS,INFOSYS,IBM
}
