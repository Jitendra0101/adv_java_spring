package dependency;

public class SmsBased implements NotificationService{

	public SmsBased() {
	System.out.println("in const of : " + getClass().getName());
	}
	
	@Override
	public void alertCustomer(String mesg) {
		// TODO Auto-generated method stub
		System.out.println("sending an alert through SMS...");
		
	}

}
