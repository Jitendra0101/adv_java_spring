package dependency;

public interface NotificationService {

	public void alertCustomer(String mesg);

}
