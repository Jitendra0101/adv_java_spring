package dependency;

public class EmailBased implements NotificationService {

	public EmailBased() {
		System.out.println("in constructor of: " + getClass().getName());
	}

	@Override
	public void alertCustomer(String mesg) {
		// TODO Auto-generated method stub
		System.out.println("sending an alert through email...");

	}

}
