package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	public HomeController() {
		System.out.println("in home ctor");
	}
	
	//Key: /
	//value: HomeController.TestMe2
	@RequestMapping("/")
	public String TestMe2() {
		System.out.println("in Testme 2 ");
		return "/index";//Handler rets LVN -->D.S -->V.R-->AVN
	}
	
	

}
