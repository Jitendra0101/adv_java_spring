package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {
	public TestController() {
		System.out.println("in ctor of"+ getClass());
	}
	
	@RequestMapping("/test1")
	public String testMe1() {
		System.out.println("in testMe1");
		return "/display";
	}
	
	
}
