package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.DepartmentDao;
import com.app.pojos.Department;


@Service
@Transactional
public class DepartmentServiceImpl implements DepartmentService {
	
	@Autowired
	private DepartmentDao deptDao;

	@Override
	public List<Department> listAllDepartments() {
		
		return deptDao.getAllDepartment();
	}

	@Override
	public String addDepartment(Department addDept) {
		
		return deptDao.addDepartment(addDept);
	}

}
